import React, { Component } from "react";

class Rentals extends Component {
  state = {};
  render() {
    return <h1>Rental Page</h1>;
  }
}

export default Rentals;
